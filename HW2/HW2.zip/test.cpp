#include <iostream>
#include "stdlib.h"
#include "string.h"
// // #include "file.h"
// // #include "folder.h"
// // #include "directory.h"
// // #include <map>
// #include <vector>
// #include "_helper/parse_file_path.h"

using namespace std;

// void read_list(string list[] , int num_items = 0)
// {
//     for(int i = 0; i < num_items; i++)
//         cout << list[i] << endl;
// }

int main()
{
    // vector<string> str;
    // str.push_back("1");
    // str.push_back("2");
    // str.push_back("3");
    // str.erase(str.begin() +1);
    // for(int i =0; i < str.size(); i++){
    //     cout << str[i] << endl;
    // }
    string s = "010";
    int c = s[1] - 48;
    cout << c << endl;
    return 0;
}